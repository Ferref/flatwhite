# Flatwhite

A package for validating formats and handling files.

## Installation

You can install the package using pip:

```bash
pip install flatwhite
